package main;

import menu.MainMenu;

public class Main {
    public static void main(String[] args){
        //Inizializzare menù
        MainMenu.mainLoop();
    }
}

